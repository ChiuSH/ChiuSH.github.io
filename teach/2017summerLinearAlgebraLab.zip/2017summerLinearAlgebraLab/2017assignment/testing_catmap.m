Y=imread('image_1.jpg');
Y1=Y;
for i=1:1003;
    X1=Y1;
    Y1 = catmap(X1);
    D=sum(Y1(:,:,1)-Y(:,:,1))+ sum(Y1(:,:,2)-Y(:,:,2))+sum(Y1(:,:,3)-Y(:,:,3));
    if (D==0)
        disp(i);
        Y2=Y1;
        break;
    end
end
%Y1 = uint8(Y1);
    