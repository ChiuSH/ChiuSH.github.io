% Project 2 : Chaotic Dynamics


% Rename this file by replacing 'lastname' and 'PSID' with your own

% PROVIDE THE FOLLOWING INFORMATION

% NAME: 
% PSID: 

%% Block One

[U,E]=eig([2 1; 1 1]);
e2=E(2,2);
v2=U(:,2);


 x=[0 1 1 0 0];
 y=[0 0 1 1 0];

plot(x,y);hold on;
 U1=U*[x;y];
 axis equal;
 plot(U1(1,:),U1(2,:));hold on;
 U2=E*U1;
 plot(U2(1,:),U2(2,:));hold on;
 U3=U*U2;
 plot(U3(1,:),U3(2,:));hold on;
 
 E4=[2 1; 1 1]*[x;y]; 
 plot(E4(1,:),E4(2,:));hold on;
 



%% Block Two

%% Block Three 


%% Block Four
figure;
%Y = 'image_1.jpg';
%Y = 'image_2.jpg';
%Y = 'image_3.jpg';
X = imread(Y);
for i = 1:200
   X = catmap(X);
   image(X);
   title(i);
   refresh;
   pause(0.001);
end
