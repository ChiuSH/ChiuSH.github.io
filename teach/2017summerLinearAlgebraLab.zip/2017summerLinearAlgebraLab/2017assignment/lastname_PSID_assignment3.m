%% Matlab Assignment 3, 

% Enter your name and PSID below
%
%  First Name: 
%  Last Name:
%  PSID:



% INSTRUCTIONS:
% ------------
% - Rename this file: replace 'lastname' and 'PSID' with your own
%  
% - Enter your codes in each code block. Add lines as necessary. You may
%   also add comments where needed, such as explanations.
%
% - Once you are done, upload it on Blackboard. 
%   Remember, only ONE submission is allowed on Blackboard!
%
% - Suppress outputs unless otherwise stated.



%% 1

%% 2

%% 3

%% 4

%% 5

%% 6

%% 7

%% 8

%% 9

%% 10

%% 11

%% 12
