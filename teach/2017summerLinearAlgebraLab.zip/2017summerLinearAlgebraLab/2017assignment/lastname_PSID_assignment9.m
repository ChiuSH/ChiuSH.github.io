% Assignment 9: Computational Time


% Rename this file by replacing 'lastname' and 'PSID' with your own

% PROVIDE THE FOLLOWING INFORMATION

% NAME: 
% PEOPLESOFT: 

%% 1

%% 2

%% 3

%% 4

%% 5

%% 6

%% 7

%% 8

%% 9
