%% Matlab Assignment 8, 

% Enter your name and PSID below
%
%  First Name: 
%  Last Name:
%  PSID:



% INSTRUCTIONS:
% ------------
% - Rename this file: replace 'lastname' and 'PSID' with your own
%   For example, my filename should be "smith_1234567_MAT1.m"
%
% - Enter your codes in each code block. Add lines as necessary. You may
%   also add comments if you wish (nothing irrelevant or inappropriate!).
%
% - Once you are done, upload it on Blackboard. 
%   Remember, only ONE submission is allowed on Blackboard!


%% 1














%% 2


