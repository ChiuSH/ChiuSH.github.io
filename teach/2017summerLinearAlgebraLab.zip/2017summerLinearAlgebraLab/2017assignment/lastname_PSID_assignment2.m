%% Matlab Assignment 2, 

% Enter your name and PSID below
%
%  First Name: 
%  Last Name:
%  PSID:



% INSTRUCTIONS:
% ------------
% - Rename this file: replace 'lastname' and 'PSID' with your own
%  
%
% - Enter your codes in each code block. Add lines as necessary. You may
%   also add comments if you wish (nothing irrelevant or inappropriate!).
%
% - Once you are done, upload it on Blackboard. 
%   Remember, only ONE submission is allowed on Blackboard!


% =========================================================================


%% 0. Paste the code to generate the cat picture here


%% 1.  Reflection though the x axis 


%% 2.  Reflection though the axis y=x


%% 3.  Reflection though the origin


%% 4.  Vertical Contractions by factor 1/3


%% 5.  Horizontal Contraction  by a factor 2/5 


%% 6.  Horizontal Expansions by a factor 3


%% 7. Vertical Shears by a factor of -1.5 


%% 8. Projection onto the y axis


%% 9. Rotation by an angle of  pi/4  clockwise and counterclockwise 


%% 10. Rotation by an angle of  2*pi/5  clockwise and counterclockwise 

