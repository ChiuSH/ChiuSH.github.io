% Project 2 : Chaotic Dynamics


% Rename this file by replacing 'lastname' and 'PSID' with your own

% PROVIDE THE FOLLOWING INFORMATION

% NAME: 
% PSID: 

%% Block One

%% Block Two

%% Block Three 


%% Block Four
figure;
%Y = 'image_1.jpg';
%Y = 'image_2.jpg';
%Y = 'image_3.jpg';
X = imread(Y);
for i = 1:200
   X = catmap(X);
   image(X);
   title(i);
   refresh;
   pause(0.001);
end
