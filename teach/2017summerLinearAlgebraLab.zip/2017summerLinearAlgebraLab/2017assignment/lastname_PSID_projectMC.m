% Project 3 : Markov Chain


% Rename this file by replacing 'lastname' and 'PSID' with your own

% PROVIDE THE FOLLOWING INFORMATION

% NAME: 
% PEOPLESOFT: 

%% Question1

%% Question2


