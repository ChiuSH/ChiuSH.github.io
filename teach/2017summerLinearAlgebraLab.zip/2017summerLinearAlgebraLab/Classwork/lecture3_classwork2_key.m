% These are the commands for week4 classwork2
% Question 1. first we build up matrix M
M=[1 2 3 4; 3 5 6 3;5 4 1 9;1 3 0 2];
% Then capture the first to second row and first to second colume of M to be A1
A1=M(1:2,1:2)

% Question 2. Capture the third to fourth row and second to fourth colume
% of M t be A2
A2=M(3:4,2:4)

% Question 3. To build a block matrix A=[A1, A2; 3x2 ones matrix, 3x3 identiy]
A=[A1, A2; ones(3,2), eye(3)];

% Question 4. To bild a block diagonal matrix B 
B1=rand(2);
B2=eye(2)+8;
B3=[3 6;4 2;9 1];
B=blkdiag(B1,B2,B3)

% Question 5. Create a symmetric matrix N from the matrix M such that the
% upper triagular part of N is the upper triagular part of M

%First we produce the upper triangular part of M to be N1
N1=triu(M);
%Then we transpose N1 to get a lower triangular matrix without diagonal
%elements by controling the diagnoal number k(see note)
N2=tril(N1',-1);

%Then combine N1 and N2 to get N
N=N1+N2