function X = cramer_inverse3(Y)
% Using Cramer's rule to find the inverse martix X of matrix Y
n=size(Y,1);
m=size(Y,2);

%Check if Y is a square matrix
if (n~=m) 
    disp('Error: The input array is not a square matrix.');
    return;
end
%Check if Y is singular
if (det(Y)==0)
    disp('Error: The input matrix is singular.');
    return;
end
%Check if Y is a 3x3 matrix
if (n~=3)
    disp('Error: The input matrix is not a 3x3 matrix.');
    return;
end
%Using Cramer's rule to find inverse matrix X 
I=eye(n);
X=zeros(size(Y));

Y1=[I(:,1),Y(:,2:3)];Y2=[Y(:,1),I(:,1),Y(:,3)];Y3=[Y(:,1:2),I(:,1)];
X(:,1)=[det(Y1)/det(Y);det(Y2)/det(Y);det(Y3)/det(Y)];

Y1=[I(:,2),Y(:,2:3)];Y2=[Y(:,1),I(:,2),Y(:,3)];Y3=[Y(:,1:2),I(:,2)];
X(:,2)=[det(Y1)/det(Y);det(Y2)/det(Y);det(Y3)/det(Y)];

Y1=[I(:,3),Y(:,2:3)];Y2=[Y(:,1),I(:,3),Y(:,3)];Y3=[Y(:,1:2),I(:,3)];
X(:,3)=[det(Y1)/det(Y);det(Y2)/det(Y);det(Y3)/det(Y)];











