% load the data of BATMAN
load 'batmanx.txt';
load 'batmany.txt';

% name these two files

x1=batmanx;
y1=batmany;

% plot the batman logo
plot(x1,y1)
axis equal;
hold on; %put hold on then you can see it after drawing ellipse


% draw an ellipse covering of the logo
%x2 and y2 are the parameters of an ellipse with respect to the angle t

t=linspace(0,2*pi,300);
x2=8*cos(t);
y2=4*sin(t);
plot(x2,y2);

% Shear transformation
A=[1 3;0 1];
A1=A*[x1;y1];
A2=A*[x2;y2];
plot(A1(1,:),A1(2,:)); hold on;
plot(A2(1,:),A2(2,:))


%  rotating the logo by pi/3 clockwisely then expanding $3$ times in horizontal direction
%  rotating the logo by pi/3 clockwisely is the same as rotating the logo by 5*pi/3 counterclockwisely
B1=[cos(5*pi/3),-sin(5*pi/3); sin(5*pi/3) , cos(5*pi/3) ]; % rotating
B2=[3 0;0 1]; % expanding 
B3=B2*B1*[x1;y1];
B4=B2*B1*[x2;y2];
plot(B3(1,:),B3(2,:)); hold on;
plot(B4(1,:),B4(2,:))
