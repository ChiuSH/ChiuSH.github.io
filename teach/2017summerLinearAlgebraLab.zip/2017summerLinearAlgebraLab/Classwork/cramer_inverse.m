function X = cramer_inverse(Y)
% Using Cramer's rule to find the inverse martix X of matrix Y
n=size(Y,1);
m=size(Y,2);
%Check if Y is a square matrix
if (n~=m) 
    disp('Error: The input array is not a square matrix.');
    return;
end
%Check if Y is singular
if (det(Y)==0)
    disp('Error: The input matrix does not exist.');
    return;
end
%Using Cramer's rule to find inverse matrix X 
I=eye(n);
X=zeros(size(Y));
for j=1:n;
    for i=1:n;
        Y1=Y;
        Y1(:,i)=I(:,j);
        X(i,j)=det(Y1)/det(Y);
    end
end