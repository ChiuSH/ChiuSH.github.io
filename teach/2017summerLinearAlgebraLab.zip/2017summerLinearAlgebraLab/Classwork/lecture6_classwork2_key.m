% assign the matrix A
A=[0 1 4; 1 2 -1;5 8 0];
rank(A);
det(A);
% Set B for switching the first column and second column of A
B=[A(:,2),A(:,1),A(:,3)];
det(B);
% Set the first column of C is the first column of A minus the second column of A
C=[A(:,1)-A(:,2),A(:,2),A(:,3)];
det(C);
% input matrix D
D=[1 -4 2; 1 8 -9; -1 7 0];
rank(D);
det(D);
% Set the first column of E is the addition of 3*(the first column of D)
% and 2*(the second column of D)
E=[3*D(:,1)+2*D(:,2),D(:,2),D(:,3)];
det(E);

 %Extra: row reduction: find a upper triangle matrix F 
 %set the first row of F = the row column of D
 %Set the second row of F = the row column of D-the first row of D
 %set the third row of F=the first column of D+the third row of D
 
 F=[D(1,:);D(2,:)-D(1,:);D(3,:)+D(1,:)];
 
 %Set the third row of new F to be -1/4*(the second row of old F)+the third row of old F
 F=[F(1,:);F(2,:);-0.25*F(2,:)+F(3,:)];
 
 det(F);
 
 
 %trace of D and trace of D'
 trace(D);
 trace(D');
 
 %
  trace(A+D);
  trace(A)+trace(D);
  
  %
  trace(A*D);
  trace(A)*trace(D);
  
  %
  trace(3*D);
  3*trace(D);
