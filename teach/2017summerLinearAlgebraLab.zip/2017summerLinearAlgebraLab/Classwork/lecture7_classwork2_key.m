%%lecture7_classwork2
%% Draw a right triangle by using drawpoly
T=[0 3 3 0; 0 0 4 0];
drawpoly(T);

%%Do the eig-decomposition on catmap

[U,E]=eig([2 1; 1 1]);
e1=E(1,1);
v1=U(:,1);
%% draw the segment 
L1=[1/2 1/5; 1/2 1/3]% First column is first point and second column is the second one
drawpoly(L1);
d=sqrt(sum((L1(:,2)-L1(:,1)).^2));% Find the distance

%% use catmap matrix to do the transformation
A=[2 1; 1 1];

%The projection of L1 on v1
LV1=L1(:,2)-L1(:,1)% move the vector to the origin
DL1=abs(dot(v1,LV1));% the projection of LV1 on v1 direction. The result of dot can be negative
                     % (what is the geometrical meaning when we got a negative projection?)

%first iteration
L2=A*L1;
LV2=L2(:,2)-L2(:,1)% move the vector to the origin
DL2=abs(dot(v1,LV2));% the projection of LV2 on v1 direction. the result of dot can be negative
Ratio2=DL2/DL1; %check Ratio2 equals e1

%second iteration
L3=A*L2;
LV3=L3(:,2)-L3(:,1)% move the vector to the origin
DL3=abs(dot(v1,LV3));% the projection of LV3 on v1 direction. the result of dot can be negative
Ratio3=DL3/DL2; %check Ratio3 equals e1



