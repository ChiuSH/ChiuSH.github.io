%%Week11_classwork2
%%1. 
%(i) 
A=[2 1 ; 1 1];
[U,E]=eig(A);
%(iii)
U*E*inv(U)
%(vi)
x=[0 1 1 0 0];
y=[0 0 1 1 0];
plot(x,y); hold on;
axis([-3 3 -3 3]);
axis equal;
%(v)
U5=inv(U)*[x;y];
plot(U5(1,:),U5(2,:)); hold on;
%(vi)
U6=E*U5;
plot(U6(1,:),U6(2,:)); hold on;
%(vii)
U7=U*U6;
plot(U7(1,:),U7(2,:)); hold on;
%(viii)
U8=A*[x;y];
plot(U8(1,:),U8(2,:)); hold on;


%%2. Solving the system Ax=b by using elementary matrices

%% From the given system, we have

A=[2 1 1;
  -1 0 2;
   3 1 3];
b=[4; 2;-2];

Ab=[A,b]; % We need to combine the matrix A and vector b to do the row reducation.
%%(i) 
%% switch first row and second row of Ab
Ab1=[Ab(2,:);Ab(1,:);Ab(3.:)];

%% change the sign of first row of Ab1
Ab2=[-Ab1(1,:);Ab1(2:3,:)];

%% -2*(the first row of Ab2)+(the second row of Ab2)=the second row of Ab3
Ab3=[Ab2(1,:);-2*Ab2(1,:)+Ab2(2,:);Ab2(3.:)];

%% -3*(the first row of Ab3)+(the third row of Ab3)=the third row of Ab4 
Ab4=[Ab3(1:2,:);-3*Ab3(1,:)+Ab3(3.:)];

%% -1*(the second row of Ab4)+(the third row of Ab4)=the third row of Ab5
Ab5=[Ab4(1:2,:);-1*Ab4(2,:)+Ab4(3.:)];

%% (1/4)*(the third row of Ab5)= the third row of Ab6
Ab6=[Ab5(1:2,:);(1/4)*Ab5(3.:)];

%%2*(the third row of Ab6)+(the first row of Ab6)=the first row of Ab7
Ab7=[Ab6(1,:)+2*Ab6(3.:); Ab6(2:3,:)]; 

%% -5*(the third row of Ab7)+(the second row of Ab7)=the second row of Ab8
Ab8=[Ab7(1,:);-5*Ab7(3,:)+Ab7(2,:);Ab7(3.:)];

x_r=Ab8(:,4)%% Get the answer of this system by row reducation

%%(ii) First find out those elementary matrices
%% switch first row and second row of Ab

E1=[0 1 0;
    1 0 0;
    0 0 1 ];

%% change the sign of first row of Ab1

E2=[-1 0 0;
     0 1 0;
     0 0 1];

%% -2*(the first row of Ab2)+(the second row of Ab2)=the second row of Ab3

E3=[1 0 0;
   -2 1 0;
    0 0 1];

%% -3*(the first row of Ab3)+(the third row of Ab3)=the third row of Ab4 

E4=[1 0 0;
    0 1 0;
   -3 0 1];


%% -1*(the second row of Ab4)+(the third row of Ab4)=the third row of Ab5

E5=[1 0 0;
    0 1 0;
    0 -1 1];

%% (1/4)*(the third row of Ab5)= the third row of Ab6

E6=[1 0 0;
    0 1 0;
    0 0 1/4];

%%2*(the third row of Ab6)+(the first row of Ab6)=the first row of Ab7

E7=[1 0 2;
    0 1 0;
    0 0 1];

%% -5*(the third row of Ab7)+(the second row of Ab7)=the second row of Ab8

E8=[1 0 0;
    0 1 -5;
    0 0 1];

x_e=E8*E7*E6*E5*E4*E3*E2*E1*Ab %% Get the answer of this system by using elementary matrices










