%%Find the matrix A such that the y_n=Ay_n-1 satisfies the given formula
A=[-1 0.3 -0.2; 1 0 0; 0 1 0];
y3=[1; 10; 12];

%%Calculate the powers of A
A^10
A^100
A^1000
A^10000

A1=[A-eye(3),zeros(3,1)];
rref(A1); %% This is will give us the steady-state vector.

%%
x(1)=12; x(2)=10; x(3)=1;
for n= 4:100;
x(n)=-x(n-1)+0.3*x(n-2)-0.2*x(n-3);
end;

%%
y=1:100;
plot(y,x);
