%Using diag to create a diagonal matrix
v1=[1 2 3];
A1=diag(v1);
%Compute the matrix square of A1
A1^2;
%Compute the matrix of squred entries of A1
A1.^2;
%Compute the matrix expoential of A1
expm(A1);
%compute the exponential of all the entries ofA1
exp(A1);
%Since A1 is 3x3 so we need a 3x3 magic matrix to build up a diagonal block
%matrix B
B=blkdiag(A1,magic(3));
%Compute matrix square of B
B^2;
%Compute the matrix of squred entries of B
B.^2;
% create a 5x5 pascal matrix
P=pascal(5);
% create a 5x5 toeplitz matrix by vector [ 1 2 3 4 5]
C=toeplitz([1 2 3 4 5]);
% This is a matrix polynomial P^2-2P+I
P^2-2*P+eye(5);
% This  is matrix polynomial (P-I)^2. The result should be the same as the
% above one.
(P-eye(5))^2;
% This is a matrix polynomial A^2-3A-28I. The result should be a zero matrix.
A=[1 6; 5 2];
A^2-3*A-28*eye(2);
