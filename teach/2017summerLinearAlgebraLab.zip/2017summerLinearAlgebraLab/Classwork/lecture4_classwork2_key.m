%Your image name will be couger.jpeg .
[A,map] = imread('cougar.jpeg');
A = double(A);
n = size(A,1);
figure,imagesc(A); colormap(map) ; axis image; title('COUGAR1');

B=double(A);
% Doing SVD on red layer 
[U1,S1,V1]=svd(B(:,:,1));
k = 25;
Ak1 = U1(:,1:k)*S1(1:k,1:k)*V1(:,1:k)';
figure,imagesc(Ak1); colormap hot; axis image; title(‘red_COUGAR=25')
%figure,imagesc(B(:,:,1)); colormap gray; axis image; title('COUGAR')

% Doing SVD on second layer
[U2,S2,V2]=svd(B(:,:,2));
k = 25;
Ak2 = U2(:,1:k)*S2(1:k,1:k)*V2(:,1:k)';
figure,imagesc(Ak2); colormap winter; axis image; title(‘green_COUGAR=25')

% Doing SVD on third layer
[U3,S3,V3]=svd(B(:,:,3));
k = 25;
Ak3 = U3(:,1:k)*S3(1:k,1:k)*V3(:,1:k)';
figure,imagesc(Ak3); colormap spring; axis image; title(‘blue_COUGAR=25')

%Set a 3 layers matrix
C=zeros(183,275,3);
%assign the matrices to the layers
C(:,:,1)=Ak1;
C(:,:,2)=Ak2;
C(:,:,3)=Ak3;
%change the type of number
D=uint8(C);
%Draw the picture
figure,imagesc(D); colormap(map); axis image; title('COUGAR=25')

