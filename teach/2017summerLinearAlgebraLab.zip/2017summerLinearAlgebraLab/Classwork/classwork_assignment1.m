%Matlab Assignment 1 : In class demo
% this is a comment
% this another comment

%Create a random 5 x 5 matrix of integers
A = magic(5);

%% This is the second code block
% create a 4 x 1 vector c with all entries equal to -1
c = repmat(-1, 4, 1);

% create a 3 x 3 matrix A and display it (without using disp)
A = [1 5 2; 0 4 -7; 0 0 5];  


% create a 3 x 1 vector b, and display it using disp
b = [-6; 2; 0];
disp(b)

% Solve Ax=b, and store the solution in a variable 'x'
x = A\b;
disp(x)

%% create a random matrix
Arand = rand(6);
disp(A)

%% Slicing
A = magic(5); % this creates a 5 x 5 magic square
disp(A)

% slice row 1 and store it in a variable called 'row1'
row1 = A(1,:);
disp(row1)

% slice column 3 and store it in a variable called 'col3'
col3 = A(:,3);
disp(col3)

%% sum command
% create a vector a, sum its entries and display the sum using fprintf 
a = [1; 2; 1; 1];
disp(a)
fprintf('The sum of the entries in a is equal to %d \n', sum(a))

%% using sprintf
%% there are some details on the webstie below
%% https://www.mathworks.com/help/matlab/ref/sprintf.html

%% f means Fixed-point 
sprintf('%0.5f',0.123456789123456789)
sprintf('%0.20f',0.123456789123456789)

%% e means Exponential 
sprintf('%0.5e',0.123456789123456789)
sprintf('%0.20e',0.123456789123456789)

%% g 
sprintf('%0.5g',0.123456789123456789)
sprintf('%0.20g',0.123456789123456789)

%% using fprintf

y = 5;
x = 1.322456;

fprintf('the value of y is %d \n', y); % use '%d' for integers
fprintf('the value of x is %f \n', x); % use '%f' for decimal numbers
fprintf('\n\n') % this is used to skip 2 lines
fprintf('the value of x is up to 2 decimal places is %.2f \n', x);
fprintf('the value of x is up to 2 decimal places is %.3f \n', x);
fprintf('the value of x is up to 2 decimal places is %.5f \n', x);

fprintf('X is %4.2f meters or %8.3f mm\n',23.55555555,23.55555555);

