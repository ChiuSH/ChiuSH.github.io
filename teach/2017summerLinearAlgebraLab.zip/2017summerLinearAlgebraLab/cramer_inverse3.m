function X = cramer_inverse3(Y)
% Using Cramer's rule to find the inverse martix X of matrix Y
n=size();
m=size();

%Check if Y is a square matrix
if ( ) 
    disp('Error: The input array is not a square matrix.');
    ;
end
%Check if Y is singular
if ( )
    disp('Error: The input matrix does not exist.');
    ;
end
%Check if Y is a 3x3 matrix
if ( )
    disp('Error: The input matrix is not a 3x3 matrix.');
    ;
end
%Using Cramer's rule to find inverse matrix X 
;
X=zeros( );












