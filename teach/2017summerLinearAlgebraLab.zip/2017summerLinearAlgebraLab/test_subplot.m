

A=magic(100);
[U,S,V] = svd(A);
k1 = 25;
Ak1 = U(:,1:k1)*S(1:k1,1:k1)*V(:,1:k1)';


k2 = 50;
Ak2 = U(:,1:k2)*S(1:k2,1:k2)*V(:,1:k2)';

k3 = 100;
Ak3 = U(:,1:k3)*S(1:k3,1:k3)*V(:,1:k3)';

 
k4 = 75;
Ak4 = U(:,1:k4)*S(1:k4,1:k4)*V(:,1:k4)';

figure
subplot(2,2,1)
imagesc(Ak1)
title('k=25')

subplot(2,2,2)
imagesc(Ak2)
title('k=50')


subplot(2,2,3)
imagesc(Ak3)
title('k=100')

subplot(2,2,4)
imagesc(Ak4)
title('k=75')
