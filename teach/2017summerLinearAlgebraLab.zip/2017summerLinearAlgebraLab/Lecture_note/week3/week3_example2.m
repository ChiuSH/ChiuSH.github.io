%projection
x1=[1,2];
x2=[1,0];
d=x2-x1;
plot(1,2,'b.','MarkerSize',20);hold on;
plot(1,0,'r.','MarkerSize',20); hold on;
%plot(x,y,'b')
quiver(x1(1),x1(2),d(1),d(2),0,'b');
axis([-0.5 2.5 -0.5 2.5 ]);
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
box off;

%shear transfor.
x1=0;
x2=2;
y1=0;
y2=2;
A=[1 2;0 1];
x = [x1, x2, x2, x1, x1];
y = [y1, y1, y2, y2, y1];
plot(x, y, 'b-', 'LineWidth', 1);hold on;
plot(x,y,'b.','MarkerSize',20);hold on;
quiver(x1,y1,x2,0,0,'b');
quiver(x1,y1,0,y2,0,'b');
txt1='$\overrightarrow{\bf u}$';
text(0.7,0.3,txt1,'Interpreter','latex')
txt2='$\overrightarrow{\bf v}$';
text(0.3,0.7,txt2,'Interpreter','latex')
txt3='$\overrightarrow{\bf u}+\overrightarrow{\bf v}$';
text(2.1,2.1,txt3,'Interpreter','latex')

B=A*[x;y];
plot(B(1,:), B(2,:), 'r-', 'LineWidth', 1);hold on;
plot(B(1,:),B(2,:),'r.','MarkerSize',20);hold on;
quiver(x1,y1,B(1,2),B(2,2),0,'b');
quiver(x1,y1,B(1,4),B(2,4),0,'b');
txt1='$A\overrightarrow{\bf u}$';
text(0.7,0.3,txt1,'Interpreter','latex')
txt2='$A\overrightarrow{\bf v}$';
text(0.3,0.7,txt2,'Interpreter','latex')
txt3='$A(\overrightarrow{\bf u}+\overrightarrow{\bf v})$';
text(2.1,2.1,txt3,'Interpreter','latex')
axis equal;
axis([-0.5 7 -0.5 7 ]);
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
box off;

% horizontal expansion transfor.
x1=0;
x2=2;
y1=0;
y2=2;
A2=[3 0;0 1];
x = [x1, x2, x2, x1, x1];
y = [y1, y1, y2, y2, y1];
%plot(x, y, 'b-', 'LineWidth', 1);hold on;
%plot(x,y,'b.','MarkerSize',20);hold on;
B2=A2*[x;y];
plot(B2(1,:), B2(2,:), 'r-', 'LineWidth', 1);hold on;
plot(B2(1,:),B2(2,:),'r.','MarkerSize',20);hold on;
quiver(x1,y1,B2(1,2),B2(2,2),0,'b');
quiver(x1,y1,B2(1,4),B2(2,4),0,'b');
txt1='$A\overrightarrow{\bf u}$';
text(0.7,0.3,txt1,'Interpreter','latex')
txt2='$A\overrightarrow{\bf v}$';
text(0.3,0.7,txt2,'Interpreter','latex')
txt3='$A(\overrightarrow{\bf u}+\overrightarrow{\bf v})$';
text(2.1,2.1,txt3,'Interpreter','latex')
axis equal;
axis([-0.5 7 -0.5 7 ]);
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
box off;

%An Arrow between graphs
txt='$A$';
text(1.5,4,txt,'Interpreter','latex'); hold on;
quiver(0,3,3,0,0,'k');
axis equal; 
axis([-0.5 3.5 -0.5 7 ]);
axis off;

% verical contraction transfor.
x1=0;
x2=2;
y1=0;
y2=2;
A3=[1 0;0 1/2];
x = [x1, x2, x2, x1, x1];
y = [y1, y1, y2, y2, y1];
%plot(x, y, 'b-', 'LineWidth', 1);hold on;
%plot(x,y,'b.','MarkerSize',20);hold on;
B3=A3*[x;y];
plot(B3(1,:), B3(2,:), 'r-', 'LineWidth', 1);hold on;
plot(B3(1,:),B3(2,:),'r.','MarkerSize',20);hold on;
quiver(x1,y1,B3(1,2),B3(2,2),0,'b');
quiver(x1,y1,B3(1,4),B3(2,4),0,'b');
txt1='$A\overrightarrow{\bf u}$';
text(0.7,0.3,txt1,'Interpreter','latex')
txt2='$A\overrightarrow{\bf v}$';
text(0.3,0.7,txt2,'Interpreter','latex')
txt3='$A(\overrightarrow{\bf u}+\overrightarrow{\bf v})$';
text(2.1,2.1,txt3,'Interpreter','latex')
axis equal;
axis([-0.5 7 -0.5 7 ]);
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
box off;


