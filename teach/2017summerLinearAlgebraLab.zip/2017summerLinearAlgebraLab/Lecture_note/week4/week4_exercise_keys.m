%WEEK4 EXERCISE KEYS
%exercise1
diag(diag(A))+ones(5)-eye(5)
%exercise2
2*(ones(3)-eye(3))+diag(A(1,1:3))
%exercise3

%exercise4
triu(A)+tril(triu(A)',-1)

