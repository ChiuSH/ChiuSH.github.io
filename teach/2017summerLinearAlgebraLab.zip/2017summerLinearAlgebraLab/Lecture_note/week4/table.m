% a table

x = linspace(0,8,9);
y = linspace(0,8,9);
[xx, yy] = meshgrid(x, y);
xx = xx (:)';
yy = yy (:)';
plot(xx,yy,'k.'); hold on;
axis([-2 10 -2 10]);
axis equal;
for i=0:5;
plot(xx(i*9+1:i*9+2),yy(i*9+1:i*9+2),'k'); hold on;
end
for i=7:8;
plot(xx(i*9+1:i*9+2),yy(i*9+1:i*9+2),'k'); hold on;
end

for i=0:5;
plot(xx(i*9+4:i*9+9),yy(i*9+4:i*9+9),'k'); hold on;
end    
plot(xx(7*9+4:7*9+9),yy(7*9+4:7*9+9),'k'); hold on;
plot(xx(8*9+4:8*9+9),yy(8*9+4:8*9+9),'k'); hold on;
for i=0:5;
plot(xx(i*9+2:i*9+4),yy(i*9+2:i*9+4),'k--'); hold on;
end 
plot(xx(7*9+2:7*9+4),yy(7*9+2:7*9+4),'k--'); hold on;
plot(xx(8*9+2:8*9+4),yy(8*9+2:8*9+4),'k--'); hold on;
plot(yy(1:6),xx(1:6),'k');hold on;
plot(yy(10:15),xx(10:15),'k');hold on;
for i=0:5;
plot(yy(i*9+28:i*9+33),xx(i*9+28:i*9+33),'k');hold on;
end

for i=0:5;
plot(yy(i*9+35:i*9+36),xx(i*9+35:i*9+36),'k');hold on;
end

for i=0:5;
plot(yy(i*9+33:i*9+35),xx(i*9+33:i*9+35),'k--');hold on;
end

for i=-3:-2;
plot(yy(i*9+33:i*9+35),xx(i*9+33:i*9+35),'k--');hold on;
end

plot(yy(8:9),xx(8:9),'k');hold on;
plot(yy(17:18),xx(17:18),'k');hold on;
box off; axis off;

x1=linspace(-0.5,8.5,10);
plot(x1,8-x1,'k'); hold on

x1=linspace(-0.5,8.5,10);
plot(x1,9-x1,'b');
for i=0:4;
plot(xx(i*9+3)+0.5,yy(i*9+3),'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
end 

plot(xx(7*9+3)+0.5,yy(7*9+3),'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
for i=0:4;
plot(xx(i*9+3)+0.5,yy(i*9+3)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
end 
plot(xx(7*9+3)+0.5,yy(7*9+3)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
for i=0:4;
plot(xx(i*9+3)+0.5,yy(i*9+3)-0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
end 
plot(xx(7*9+3)+0.5,yy(7*9+3)-0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;


for i=0:4;
plot(yy(i*9+34),xx(i*9+34)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
end 
plot(yy(7),xx(7)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;

for i=0:4;
plot(yy(i*9+34)-0.5,xx(i*9+34)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
end 
plot(yy(7)-0.5,xx(7)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;

for i=0:4;
plot(yy(i*9+34)+0.5,xx(i*9+34)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;
end 
plot(yy(7)+0.5,xx(7)+0.5,'bo','MarkerSize',5,'MarkerfaceColor','b'); hold on;


txt1='$k=0$';
text(-0.5,8,txt1,'Interpreter','latex')
txt2='$k > 0$';
text(1,8.5,txt2,'Interpreter','latex')
txt3='$k< 0 $';
text(-0.5, 7.5,txt3,'Interpreter','latex')

